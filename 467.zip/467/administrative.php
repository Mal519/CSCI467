<?php

session_start();

// Include config file
include 'config.php';

?>