<?php

$servername1 = "blitz.cs.niu.edu";
$username1 = "student";
$password1 = "student";
$dbname1 = "csci467";
$port1 = 3306;

$servername2 = "localhost";
$username2 = "root";
$password2 = "";
$dbname2 = "467_database";
$port2 = 3306;
?>